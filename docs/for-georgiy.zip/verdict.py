# -*- coding: utf-8 -*-
"""Сравнение «наряд + найденная техника -> вердикт».

Зависимостей нет. Положите рядом expected_equipment.json.

Использование:
    from verdict import load_rules, parse_filename, verdict
    rules = load_rules("expected_equipment.json")
    work, brigade = parse_filename("1789_Установка_Б-1.jpg")
    result = verdict(work, detections, rules)
    # result -> {"work": "Бетонирование", "status": "confirmed", ...}
"""
import json
import os
import re
from typing import List, Dict, Optional

DEFAULT_PATH = os.path.join(os.path.dirname(__file__), "expected_equipment.json")


def load_rules(path: str = DEFAULT_PATH) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip().lower())


def resolve_work(work_name: str, rules: dict) -> Optional[str]:
    """Наряд -> каноническое имя работы из таблицы (точное или по синониму)."""
    works = rules.get("works", {})
    if work_name in works:
        return work_name
    low = _norm(work_name)
    if not low:
        return None
    for key in works:
        k = _norm(key)
        if k and (k in low or low in k):
            return key
    for syn, target in rules.get("synonyms", {}).items():
        if _norm(syn) in low:
            return target
    return None


def resolve_class(name: str, rules: dict) -> str:
    """Класс из ответа YOLO (Excavator / excavator / Экскаватор) -> slug модели."""
    low = _norm(name)
    for c in rules.get("classes", []):
        if low in (_norm(c["slug"]), _norm(c.get("en", "")), _norm(c.get("ru", ""))):
            return c["slug"]
    for c in rules.get("classes", []):
        en = _norm(c.get("en", ""))
        if en and (en in low or low in en):
            return c["slug"]
    return low


def parse_filename(filename: str) -> (Optional[str], Optional[str]):
    """<...>_<наряд>_<бригада>.jpg -> (наряд, бригада).

    Если частей меньше — считаем весь базовый имя нарядом.
    """
    base = os.path.splitext(os.path.basename(filename or ""))[0]
    parts = [p for p in re.split(r"[_]+", base) if p]
    if len(parts) >= 3:
        return parts[-2], parts[-1]
    if len(parts) == 2:
        return parts[0], parts[1]
    return (parts[0] if parts else None), None


def verdict(work_name: str, detections: List[Dict], rules: dict) -> Dict:
    """Главная функция. detections — список {"class": "...", "confidence": 0.9, "bbox": [...]}.

    Возвращает:
      work        — каноническая работа (или исходное имя)
      status      — confirmed | not_confirmed | review | unsure
      required    — какие классы ожидались
      found       — какие классы реально найдены (slug)
      detections  — сколько детекций всего
    """
    key = resolve_work(work_name, rules)
    if not key:
        return {"work": work_name, "status": "unsure",
                "required": [], "found": [], "detections": len(detections or []),
                "reason": "работа не найдена в таблице"}

    required = rules["works"][key].get("required", {})
    min_conf = rules.get("verdict", {}).get("min_confidence", 0.5)

    found: Dict[str, int] = {}
    for d in (detections or []):
        if (d.get("confidence") or 0) >= min_conf:
            slug = resolve_class(d.get("class", ""), rules)
            found[slug] = found.get(slug, 0) + 1

    if not detections:
        status = "review"              # нейросеть ничего не нашла -> прорабу «переснять»
    elif any(found.get(c, 0) >= m for c, m in required.items()):
        status = "confirmed"           # нашлась ожидаемая техника
    else:
        status = "not_confirmed"       # детекции были, но не те

    return {
        "work": key,
        "status": status,
        "required": list(required.keys()),
        "found": list(found.keys()),
        "detections": len(detections or []),
    }


if __name__ == "__main__":
    rules = load_rules()
    demo = [
        ("Бетонирование", [{"class": "Mixer", "confidence": 0.89}]),
        ("Бетонирование", [{"class": "Gazelle", "confidence": 0.70}]),
        ("Армирование", []),
        ("Установка дверей", [{"class": "Excavator", "confidence": 0.80}]),
    ]
    for w, dets in demo:
        print(w, "->", verdict(w, dets, rules))
