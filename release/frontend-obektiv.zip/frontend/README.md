# Фронтенд «Объектив» — дашборд руководителя

Готовая статичная сборка (React). Раздаётся с того же сервера, что и API.

## Как подключить (FastAPI)

Положи эту папку `frontend/` рядом с `server.py` и добавь:

```python
from fastapi.staticfiles import StaticFiles
app.mount("/app", StaticFiles(directory="frontend", html=True), name="frontend")
```

Откроется по адресу: `http://<host>:8000/app/`

## Важно
- Фронт ходит к API по относительным путям (`/health`, `/photos`, `/upload`, `/api/foreman/*`),
  поэтому CORS не нужен — всё на одном домене.
- Папка содержит: index.html, assets/, camera-zone-*.webp (демо-кадры зон).
